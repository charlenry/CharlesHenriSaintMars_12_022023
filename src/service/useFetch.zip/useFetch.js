import { useEffect, useState } from "react";

const useFetch = (url) => {
  const [data, setData] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [hasError, setHasError] = useState(false);
  const [errorType, setErrorType] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!url) return;
    setIsLoading(true);

    async function fetchData() {
      try {
        const response = await fetch(url);
        const result = await response.json();
        if(result == "can not get user") {
          setData("can not get user");
        } else {      
          setData(result.data);
          setSessions(result.data.sessions);
        }
      } catch (err) {
        setHasError(true);
        setErrorType(err.message);
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [url]);

  console.log('Valeur de data from usefetch: ', data);
  return {data, sessions, hasError, errorType, isLoading};
}


export default useFetch;